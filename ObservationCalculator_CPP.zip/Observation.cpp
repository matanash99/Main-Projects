#include "Observation.h"






Observation::Observation(const std::string& name, int dimension, float* values)
        : name(name), dimension(dimension), values(new float[dimension]) {
    for (int i = 0; i < dimension; i++) {
        this->values[i] = values[i];
    }
}

//Destroy
Observation::~Observation(){

    delete[] values;

}

//Copy
Observation::Observation(const Observation& other) {
    this->name = other.name;
    this->dimension = other.dimension;
    this->values = new float[dimension];
    for (int i = 0; i < dimension; ++i) {
        this->values[i] = other.values[i];
    }
}

//Operator=
Observation& Observation::operator=(const Observation& other) {
    if (this == &other) {
        return *this;  // Prevent self-assignment
    }

    delete[] values;  // Free old values array

    this->name = other.name;
    this->dimension = other.dimension;
    this->values = new float[dimension];
    for (int i = 0; i < dimension; ++i) {
        this->values[i] = other.values[i];  // Copy new values
    }

    return *this;
}



//Prints observation
void Observation::printObservation(){

    int i;
    cout << name << " = [ ";
    for (i = 0; i < dimension - 1 ; i++) {
        cout << values[i] << " ";
    }
    cout << values[i] <<  "]" << endl;
}

const string& Observation::getName(){
    return name;
}

float* Observation::getValues() {
    return values;
}

void Observation::setValues(float* newValues) {

    delete[] values; // Free old memory
    values = new float[dimension]; // Allocate new memory
    for (int i = 0; i < dimension; ++i) {
        values[i] = newValues[i];
    }
}