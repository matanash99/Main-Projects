#include <iostream>
#include <sstream>
#include "ObservationCalculator.h"


void main_menu(){
    cout << "[1] New observation\n" << "[2] Print observation\n";
    cout << "[3] Expected value vector\n"<< "[4] Covariance matrix\n"<< "[5] Exit\n";

}

int main(int argc, char* argv[]) {


    int dimObservations = stoi(argv[1]);
    int numObservations= stoi(argv[2]);


    ObservationCalculator* oc1 = new ObservationCalculator(dimObservations, numObservations);

    //Switch cases of user
    main_menu();
    int choice = 0;
    while (choice != 5){

        cin >> choice;
        switch(choice) {



            case 1: {
                oc1->addObservation();
                break;
            }

            case 2: {
                oc1->printObservation();
                break;

            }

            case 3: {

                oc1->printMean();
                break;
            }

            case 4: {
                oc1->printCovariance();
                break;
            }


            case 5:
                break;

            default:
                cerr << "Invalid option\n";

        }
    }
    //Delete dynamically allocated memory

    return 0;
}

