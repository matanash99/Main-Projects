#ifndef EXERCISE_1_OBSERVATIONCALCULATOR_H
#define EXERCISE_1_OBSERVATIONCALCULATOR_H
#include "Observation.h"

//Observation system that holds all observations created by user
class ObservationCalculator{

private:
    Observation* observations; // array of the observations added to the system
    int dimension; //of all observations in system
    int maxSize;   // max size of system
    int currSize;  // current amount of observations in system

public:

    ObservationCalculator(int dimension, int size);
    ~ObservationCalculator();

    void addObservation();
    void printObservation();
    void printMean();
    void printCovariance();
    bool isEmpty();
    float* getSumVector();

};

#endif //EXERCISE_1_OBSERVATIONCALCULATOR_H
