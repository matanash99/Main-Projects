#include <sstream>
#include "ObservationCalculator.h"


//Builder: receives, max size - max amount of observations, and dimension - dimension of the observations
ObservationCalculator::ObservationCalculator(int dimension, int maxSize) {


    this->maxSize = maxSize;
    this->dimension = dimension;
    this->currSize = 0;
    observations = new Observation[maxSize];
}

//Destroyer
ObservationCalculator::~ObservationCalculator(){
    delete[] observations;
}



//Prints observation by users' name input
void ObservationCalculator::printObservation() {

    cout << "Enter observation name:" << endl;
    string nameInput;
    cin >> nameInput;

    //Look for observation and print it
    for (int i = 0; i < currSize; i++){
        if (nameInput == observations[i].getName()){
            observations[i].printObservation();
            return;
        }
    }

    cerr << "Invalid or nonexistent observation." << endl;
}


//Adds observation to system
void ObservationCalculator::addObservation() {

    if (currSize == maxSize) {
        cerr << "Full calculator" << endl;
        return;
    }

    // Get observation name
    cout << "Enter observation name:" << endl;
    string nameInput;
    cin >> nameInput;

    // Initialize and get observation values from user
    cin.ignore();
    cout << "Enter observation values:" << endl;
    string valueInput;
    getline(cin, valueInput);

    stringstream ss(valueInput);
    float* myValues = new float[this->dimension];
    int count = 0;
    string value;

    while (getline(ss, value, ' ') && count < this->dimension) {
        myValues[count++] = stof(value);
    }

    if (count != dimension) {
        cerr << "Invalid observation." << endl;
        delete[] myValues;
        return;
    }

    // Check if observation name already exists - sets new values to observation.
    for (int i = 0; i < currSize; i++) {
        if (observations[i].getName() == nameInput) {
            observations[i].setValues(myValues);
            delete[] myValues;
            return;
        }
    }

    // Initialize observation and add to the system's data
    observations[currSize++] = Observation(nameInput, this->dimension, myValues);
    delete[] myValues;
}

float* ObservationCalculator::getSumVector(){
    float* sumVector = new float[this->dimension]();
    for (int i = 0; i < currSize; i++) {
        Observation o = observations[i];
        float* array = o.getValues();
        for (int j = 0; j < dimension; j++) {
            sumVector[j] += array[j];
        }
    }
    return sumVector;

}



//Prints mean of all observations
void ObservationCalculator::printMean() {

    if (isEmpty()) {
        cerr << "Empty calculator.\n";
        return;
    }

    //Get sum of every index of the all observations
    float* sumVector = getSumVector();
    //Print mean
    int i;
    cout << "mean = [ ";
    for (i = 0; i < dimension - 1; i++) {
        float number = sumVector[i]/currSize; //Divide by size to get average of every index
        cout << number << " ";
    }
    float number = sumVector[i]/currSize;
    cout << number <<  "]" << endl;

    delete[] sumVector;
}

//Prints the covariance of all the observations
void ObservationCalculator::printCovariance() {

    if (isEmpty()) {
        cerr << "Empty calculator.\n";
        return;
    }

    //Print cov 0 when system has only one observation
    if (currSize == 1) {
        cout << "cov = [\n";
        for (int i = 0; i < dimension; i++) {
            for (int j = 0; j < dimension; j++) {
                cout << "0 ";

            }
            cout << endl;
        }
        cout << "]" << endl;
        return;
    }

    //Get sum of every index of the all observations
    float* sumVector = getSumVector();

    //Initialize covariance matrix
    float** covariance = new float*[dimension];
    for (int i = 0; i < dimension; i++) {
        covariance[i] = new float[dimension]();
    }

    //Put values in cov matrix
    for (int i = 0; i < currSize; i++) {
        float* values = observations[i].getValues();
        for (int j = 0; j < dimension; j++) {
            for (int k = 0; k < dimension; k++) {
                covariance[j][k] += ((values[j] - sumVector[j]/currSize) * (values[k] - sumVector[k]/currSize))/ (currSize-1);
            }
        }
    }

    //Print cov matrix
    cout << "cov = [\n ";
    for (int i = 0; i < dimension; i++) {
        for (int j = 0; j < dimension; j++) {
            if (j == dimension - 1){
                cout << covariance[i][j];
            }
            else {
                cout << covariance[i][j] << " ";
            }
        }
        if (i != dimension -1) {
            cout << "\n ";
        }

    }
    cout << "\n]";

    //Delete dynamically allocated variables
    for (int i = 0; i < dimension; ++i) {
        delete[] covariance[i];
    }
    delete[] sumVector;
    delete[] covariance;
}

// Checks if system is empty
bool ObservationCalculator::isEmpty() {
    return currSize == 0;
}