
#ifndef EXERCISE_1_OBSERVATION_H
#define EXERCISE_1_OBSERVATION_H
#include <iostream>

using namespace std;

class Observation {
private:
    std::string name;
    int dimension;
    float* values;

public:
    Observation() : name(""), dimension(10), values(new float [10]){}
    Observation(const string& name, int dimension, float* values);
    Observation(const Observation& other);
    ~Observation();
    Observation& operator=(const Observation& other);
    const string& getName();
    float* getValues();
    void setValues(float* newValues);
    void printObservation();
};

#endif //EXERCISE_1_OBSERVATION_H
