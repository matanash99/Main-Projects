#ifndef EXERCISE_5_NEVERLAND_H
#define EXERCISE_5_NEVERLAND_H

#include "Graph.h"

class Neverland {
private:
    Graph<string> graph;
public:


    Neverland() = default;

    void addEdge(string& fileName); //Receives filename adds edge from data in file
    void printGraph(); // Prints every vertex and vertices connected to it in graph
    void startWithFile(const string& outputFileName); // Starts user interaction and prints to file
    void start(); // Starts user interaction and prints to cout
};


#endif //EXERCISE_5_NEVERLAND_H
