#include <fstream>
#include <sstream>
#include "Neverland.h"

void Neverland::addEdge(string& fileName) {
    ifstream file(fileName);
    if (!file.is_open()) {
        throw runtime_error(fileName + " does not exist or cannot be opened\n");
    }

    string vertex1, vertex2;
    int weight;
    if (!(file >> vertex1 >> vertex2 >> weight)) {
        throw runtime_error("node definition in " + fileName + " is invalid\n");
    }

    graph.addVertex(vertex1);
    graph.addVertex(vertex2);
    graph.addEdge(vertex1, vertex2, weight);
}

void Neverland::printGraph() {
    graph.display();
}

void Neverland::start() {
    string choice;

    while (true) {
        cin >> choice;
        if (choice == "exit")
            break;

        //If vertex doesnt exist in network
        if (graph.getVertexIndex(choice) == -1) {
            cout << choice << " does not exist in the current network\n";
            cout << "USAGE: <node> or 'exit' to terminate" << endl;
            continue;
        }

        vector<string> connectedVertices = graph.getConnectedVertices(choice);

        if (connectedVertices.empty()) {
            cout << choice << " : no outbound travel" << endl;
        } else {
            cout << choice << "\t";
            int i = 1;
            for (const auto &vertex : connectedVertices) {
                cout << vertex;
                if (i != static_cast<int>(connectedVertices.size())) {
                    cout << "\t";
                    i++;
                }
            }
            cout << endl;
        }
    }
}

void Neverland::startWithFile(const string& outputFileName) {
    ofstream outFile(outputFileName);

    if (!outFile) {
        cerr << "Error: Could not open file " << outputFileName << " for writing.\n";
        return;
    }

    string choice;
    while (true) {
        cin >> choice;
        if (choice == "exit")
            break;

        if (graph.getVertexIndex(choice) == -1) {
            outFile << choice << " does not exist in the current network\n";
            outFile << "USAGE: <node> or 'exit' to terminate\n";
            continue;
        }

        vector<string> connectedVertices = graph.getConnectedVertices(choice);

        if (connectedVertices.empty()) {
            outFile << choice << " : no outbound travel\n";
        } else {
            outFile << choice << "\t";
            int i = 1;
            for (const auto& vertex : connectedVertices) {
                outFile << vertex;
                if (i != static_cast<int>(connectedVertices.size())) {
                    outFile << "\t";
                    i++;
                }
            }
            outFile << endl;
        }
    }
    outFile.close();
}

