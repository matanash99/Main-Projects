#include <iostream>
#include "Neverland.h"

int main(int argc, char* argv[]) {
    Neverland city;
    string outputFileName = "output.dat";

    try {
        for (int i = 1; i < argc; i++) {
            string fileName = argv[i];

            if (fileName == "-o" && i + 1 < argc) {
                outputFileName = argv[i + 1];
                break;
            } else {
                city.addEdge(fileName);
            }
        }
    }

    catch (const runtime_error& e) {
        cerr << "Error: " << e.what() << "\n";
        return 1;
    }

    city.start(); //outputs to standard output - cout
    city.startWithFile(outputFileName); //outputs to output file: output.dat or argument in main if given

    return 0;
}