#ifndef EXERCISE_5_GRAPH_H
#define EXERCISE_5_GRAPH_H

#include <iostream>
#include <vector>
#include <unordered_set>
#include <queue>

using namespace std;

template <class V>
class Graph {
private:
    vector<V> vertices;
    vector<vector<int>> weightMatrix;


//    void dfs(int vertexIndex, unordered_set<int>& visited, vector<V>& result) const;
    void bfs(int startIndex, unordered_set<int>& visited, vector<V>& connectedVertices) const;

public:
    Graph() = default;

    int getVertexIndex(const V& vertex) const;
    void addVertex(const V& vertex); //add vertex to graph
    void removeVertex(const V& vertex); // removes vertex from graph
    void removeEdge(const V& vertex1, const V& vertex2); // removes edge of vertex to vertex from graph
    void addEdge(const V& vertex1, const V& vertex2, int weight); // adds edge from vertex to vertex with weight
    void displayEdges(const V& vertex) const; // displays all edges from vertex
    void setWeight(const V& vertex1, const V& vertex2, int weight); // set new weight for edge from vertex to vertex
    int getWeight(const V& vertex1, const V& vertex2) const; // return weight from vertex to vertex
    vector<V> getConnectedVertices(const V& vertex) const; // return list of connected vertices to vertex
    void display() const; //Prints every vertex and vertices connected to it in graph
};

template <class V>
void Graph<V>::removeEdge(const V& vertex1, const V& vertex2) {
    int index1 = getVertexIndex(vertex1);
    int index2 = getVertexIndex(vertex2);

    if (index1 == -1 || index2 == -1) {
        cout << "One or both vertices not found!\n";
        return;
    }

    weightMatrix[index1][index2] = 0;
}

template <class V>
void Graph<V>::displayEdges(const V& vertex) const {
    int index = getVertexIndex(vertex);
    if (index == -1) {
        cout << "Vertex not found!\n";
        return;
    }

    cout << "Edges for vertex " << vertex << ": ";
    for (int j = 0; j < weightMatrix[index].size(); ++j) {
        if (weightMatrix[index][j] != 0) {
            cout << vertices[j] << " ";
        }
    }
    cout << "\n";
}



template <class V>
int Graph<V>::getVertexIndex(const V& vertex) const {
    for (int i = 0; i < vertices.size(); i++) {
        if (vertices[i] == vertex)
            return i;
    }
    return -1; //Not found return -1
}

//Adds vertex to: vector of vertices, and the vector matrix
template <class V>
void Graph<V>::addVertex(const V& vertex) {
    if (getVertexIndex(vertex) != -1) {
        return;
    }

    vertices.push_back(vertex);
    int newSize = vertices.size();

    for (auto& row : weightMatrix) {
        row.push_back(0);
    }

    weightMatrix.push_back(vector<int>(newSize, 0));

    weightMatrix[newSize - 1][newSize - 1] = 0;
}

//Removes vertex from: vector of vertices, and the vector matrix
template <class V>
void Graph<V>::removeVertex(const V& vertex) {
    int index = getVertexIndex(vertex);
    if (index == -1) {
        cout << "Vertex not found!\n";
        return;
    }

    vertices.erase(vertices.begin() + index);
    weightMatrix.erase(weightMatrix.begin() + index);

    for (auto& row : weightMatrix) {
        row.erase(row.begin() + index);
    }
}

//Adds edge to vertex matrix
template <class V>
void Graph<V>::addEdge(const V& vertex1, const V& vertex2, int weight) {
    int index1 = getVertexIndex(vertex1);
    int index2 = getVertexIndex(vertex2);

    if (index1 == -1 || index2 == -1) {
        cout << "One or both vertices not found!\n";
        return;
    }

    if (weightMatrix[index1][index2] != 0) {
        int finalWeight = min(weightMatrix[index1][index2], weight);
        weightMatrix[index1][index2] = finalWeight;
    }

    weightMatrix[index1][index2] = weight;
}

template <class V>
void Graph<V>::display() const {
    for (const auto& v : vertices) {
        displayEdges(v);
    }
}



template <class V>
void Graph<V>::setWeight(const V& vertex1, const V& vertex2, int weight) {
    int index1 = getVertexIndex(vertex1);
    int index2 = getVertexIndex(vertex2);

    if (index1 == -1 || index2 == -1) {
        cout << "Vertex not found!\n";
        return;
    }

    if (weightMatrix[index1][index2] == 0) {
        cout << "No edge to update.\n";
        return;
    }

    if (weightMatrix[index1][index2] != 0) {
        int finalWeight = min(weightMatrix[index1][index2], weight);
        weightMatrix[index1][index2] = finalWeight;
    }
}

template <class V>
int Graph<V>::getWeight(const V& vertex1, const V& vertex2) const {
    int index1 = getVertexIndex(vertex1);
    int index2 = getVertexIndex(vertex2);

    if (index1 == -1 || index2 == -1) {
        cout << "One or both vertices not found!\n";
        return -1;
    }

    return weightMatrix[index1][index2];
}

template <class V>
void Graph<V>::bfs(int startIndex, unordered_set<int>& visited, vector<V>& connectedVertices) const {
    queue<int> q;
    visited.insert(startIndex);
    q.push(startIndex);

    while (!q.empty()) {
        int current = q.front();
        q.pop();

        for (int i = 0; i < weightMatrix[current].size(); ++i) {
            if (weightMatrix[current][i] != 0 && visited.find(i) == visited.end()) {
                visited.insert(i);
                connectedVertices.push_back(vertices[i]); // Add only other connected vertices
                q.push(i);
            }
        }
    }
}

template <class V>
vector<V> Graph<V>::getConnectedVertices(const V& vertex) const {
    vector<V> connectedVertices;
    int vertexIndex = getVertexIndex(vertex);

    if (vertexIndex == -1) {
        cout << "Vertex not found!\n";
        return connectedVertices;
    }

    unordered_set<int> visited;
    bfs(vertexIndex, visited, connectedVertices);

    return connectedVertices;
}


#endif // EXERCISE_5_GRAPH_H
