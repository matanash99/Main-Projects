import pandas as pd

def dataFrame():

    #2
    df = pd.read_csv("data_full.csv")
    
    
    #3
    year_2000_data = df[df["Year"] == 2000]
    year_2000_measurement= year_2000_data["Measurement"].sum()/366
    print("Average for 2000:", year_2000_measurement)
    
    #4
    median_measurement_index = int(year_2000_data["DoY"].median())
    median_measurement = year_2000_data.loc[year_2000_data["DoY"] == median_measurement_index, "Measurement"]
    print(f"Median for 2000: {median_measurement}")
    
    
    #5
    monthly_total_rain = df.groupby("Month")["Measurement"].sum()
    max_rain_month = monthly_total_rain.idxmax()
    print(f"Month with most rain: {max_rain_month}")
    
    #6
    monthly_measurement_count = df.groupby('Month')['Measurement'].count()
    max_measurement_month = monthly_measurement_count.idxmax()
    print(f"Month with the most days of rain: {max_measurement_month}")
    
    #7
    daily_measurement_count = df.groupby("DoY")["Measurement"].count()
    max_measurement_day = daily_measurement_count.idxmax()
    print(f"Day of year with the most days of rain: {max_measurement_day}")
    
    #8
    max_day = df[df["DoY"] == max_measurement_day]
    median_measurement = max_day["Measurement"].median()
    print(f"Median measurement for day {max_measurement_day}: {median_measurement}")

    #9
    most_rainy_day = df.loc[df["Measurement"].idxmax()]
    most_rainy_day_measurement = most_rainy_day["Measurement"]
    print(f"Maximum measurement: {most_rainy_day_measurement}")
    
    #10
    most_rainy_day_date = most_rainy_day["Year"]
    print(f"Year of most rainy day: {most_rainy_day_date}")
    
    #11
    yearly_rain = df.groupby('Year')['Measurement'].sum()
    years_with_less_rain = (yearly_rain < yearly_rain.shift(1)).sum()
    print(f"Number of years with less rain than the previous year: {years_with_less_rain}")
   
    #12
    yearly_rain_days = df.groupby("Year")["Measurement"].count()
    years_with_less_days = (yearly_rain_days < yearly_rain_days.shift(1)).sum()
    print(f"Number of years with less days of rain than the previous year: {years_with_less_days}")
    

if __name__ == '__main__':
    dataFrame()