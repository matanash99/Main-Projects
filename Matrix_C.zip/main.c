#include <stdio.h>
#include <stdlib.h>
#include <time.h>

//Matan Ashkenazi, 209756188

int get(int* matrix,unsigned int rows, unsigned int cols, unsigned int x, unsigned int y) {
    if (x >= cols || y >= rows) {
        printf("Invalid input");
        exit(1);
    }
    else {
        return matrix[y * cols + x];
    }
}

void set(int* matrix,unsigned int rows, unsigned int cols, unsigned int x, unsigned int y,int val){
    if (x >= cols || y >= rows) {
        printf("Invalid input");
        exit(1);
    }
    else {
        matrix[y * cols + x] = val;
    }
}

void full(int* matrix,unsigned int rows, unsigned int cols, int val) {

    for(int i = 0; i < cols*rows; i++){
        matrix[i] = val;
    }
}

void transpose(int* transpose_matrix, int* matrix, unsigned int rows, unsigned int cols) {
    for (int y = 0; y < rows; y++){
        for (int x = 0; x < cols; x++){
            transpose_matrix[x*rows+ y] = get(matrix, rows, cols, x, y);
        }
    }
}

void print(int* matrix, unsigned int rows, unsigned int cols){
    for (int i = 0; i < rows; i++) {
        for (int j = 0; j < cols; j++) {
            printf("%d\t", matrix[i * cols + j]);
        }
        printf("\n");
    }
    printf("\n");
}

void test_function_calls(unsigned int iterations){
    int test_matrix[25];
    srand(42);
    full(test_matrix, 5, 5, 0);

    //Without get+set
    size_t t0 = time(NULL);
    for (int i = 0; i<iterations; i++) {
        int ran_num = rand();
        int mod_25 = ran_num % 25;
        int x = mod_25%5;
        int y = mod_25/5;
        int *value = &test_matrix[y*5 + x];
        (*value)++;
    }

    size_t t1 = time(NULL);
    int elapsed_time1 = difftime(t1, t0);
    printf("Access without calling get+set: %d\n", elapsed_time1);

    //With get+set
    full(test_matrix, 5, 5, 0);
    size_t t2 = time(NULL);
    for (int i = 0; i < iterations; i++) {
        int ran_num = rand();
        int mod_25 = ran_num%25;
        int x = mod_25%5;
        int y = mod_25/5;
        int val = get(test_matrix, 5, 5, x, y);
        val++;
        set(test_matrix, 5, 5, x, y, val);
    }
    size_t t3 = time(NULL);

    int elapsed_time2 = difftime(t3, t2);
    printf("Access with calling get+set: %d\n", elapsed_time2);

}

void test_locality(unsigned int iterations) {
    static int matrix[100*2000000];
    srand(42);
    full(matrix,100,2000000,0);

    //Columns first
    size_t t0 =time(NULL);
    for (int i = 0; i < iterations; i++){
        for (int y = 0; y < 100; y++){
            for (int x = 0; x < 2000000; x++){
                matrix[y*2000000+ x]++;

            }
        }
    }
    size_t t1 = time(NULL);
    int elapsed_time1 = difftime(t1, t0);
    printf("Access while going over columns and then rows: %d\n", elapsed_time1);

    //Rows first
    full(matrix,2000000,100,0);
    size_t t2 =time(NULL);
    for (int i = 0; i < iterations; i++){
        for (int x = 0; x < 2000000; x++){
            for (int y = 0; y < 100; y++){
                matrix[y*2000000+ x]++;
            }
        }
    }
    size_t t3 = time(NULL);
    int elapsed_time2 = difftime(t3, t2);
    printf("Access while going over rows and then columns: %d\n", elapsed_time2);
}

void clear_stdin() {
    int c;
    while ((c=getchar()) != '\n' && c!= EOF) {}
}

int main(void) {

    //Menu
    int choice;
    while (1) {
        printf("Choose:\n"
               "1. Create a matrix\n"
               "2. Transpose a matrix\n"
               "3. Test functionality call\n"
               "4. Test locality\n"
               "Your choice:\n");

        if (scanf("%d", &choice) == 1) {
            clear_stdin();

            if (choice == 1 || choice == 2 || choice == 3 || choice == 4) {
                break; //Valid choice - break
            }
            else {
                printf("Wrong choice! Choose an integer between 1-4\n");
            }
        }
        else {
            printf("Wrong choice! Choose an integer between 1-4\n");
            clear_stdin();
        }
    }

    switch (choice) {

        case 1: {
            // Create matrix
            unsigned int rows_input, cols_input;
            while (1) {
                printf("Enter the number of rows and columns of the matrix in the format rows, columns:\n");
                if (scanf("%u, %u", &rows_input, &cols_input) == 2){
                    break;
                }
                else {
                    printf("Error, the number of rows and columns must be positive integers.\n");
                    clear_stdin();
                }
            }

            int create_matrix[rows_input][cols_input];
            int value = 0;
            for (unsigned int i = 0; i < rows_input; ++i) {
                for (unsigned int j = 0; j < cols_input; ++j) {
                    create_matrix[i][j] = value++;
                }
            }
            print(create_matrix, rows_input, cols_input);
            break;
        }

        case 2: {
            unsigned int rows_input, cols_input;
            while (1) {
                printf("Enter the number of rows and columns of the matrix in the format rows, columns:\n");
                if (scanf("%u, %u", &rows_input, &cols_input) == 2){
                    break;
                }
                else {
                    printf("Error, the number of rows and columns must be positive integers.\n");
                    clear_stdin();
                }
            }

            int create_matrix[rows_input][cols_input];
            int value = 0;
            for (unsigned int i = 0; i < rows_input; ++i) {
                for (unsigned int j = 0; j < cols_input; ++j) {
                    create_matrix[i][j] = value++;
                }
            }
            int transposed_matrix[rows_input*cols_input];
            transpose(transposed_matrix,create_matrix,rows_input,cols_input);
            print(transposed_matrix,cols_input,rows_input);
            break;
        }

        case 3: {
            int iterations;
            while (1){
                printf("How many iterations?\n");
                if (scanf("%d", &iterations) == 1) {
                    clear_stdin();
                    if (iterations >= 0 && iterations <=  1500000000){
                        break;
                    }
                    else {
                        printf("Wrong choice! Choose a positive integer between 0 to 1500000000\n");
                        clear_stdin();
                    }
                }
                else {
                    printf("Wrong choice! Choose a positive integer between 0 to 1500000000\n");
                    clear_stdin();
                }
            }
            test_function_calls(iterations);
            break;
        }

        case 4: {
            int iterations;
            while (1){
                printf("How many iterations?\n");
                if (scanf("%d", &iterations) == 1) {
                    clear_stdin();
                    if (iterations >= 0 && iterations <=  100){
                        break;
                    }
                    else {
                        printf("Wrong choice! Choose a positive integer between 0 to 100\n");
                    }

                }
                else {
                    printf("Wrong choice! Choose a positive integer between 0 to 100\n");
                    clear_stdin();
                }
            }
            test_locality(iterations);
            break;
        }
    }
    return 0;
}