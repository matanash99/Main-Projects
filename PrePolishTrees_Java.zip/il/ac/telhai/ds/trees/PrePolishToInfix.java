package il.ac.telhai.ds.trees;

import java.io.*;

public class PrePolishToInfix {

	public static void main(String[] args) throws IOException {
		System.out.println("Enter Prepolish term ( + 1 3 = [3 + 1]):");
		StreamTokenizer tokenizer = new StreamTokenizer(new InputStreamReader(System.in));
		tokenizer.slashSlashComments(false);
		tokenizer.ordinaryChar('/');
		ExpressionTree expr = ExpressionTree.createTree(tokenizer);
		System.out.println("Infix: " + expr.infix());
		System.out.println("Prefix: " + expr.prefix());
		System.out.println("Postfix: " + expr.postOrder());
		System.out.println("Value: " + expr.evaluate());
		System.out.println("Height: " + expr.height());
		System.out.println("Size: " + expr.size());
		System.out.println("IsLeaf: " + expr.isLeaf());
	}
}