package il.ac.telhai.ds.trees;


public class DLinkedListStack <T> implements Stack<T> {


    //Fields
    private DLinkedList<T> list;



    //Builder
    public DLinkedListStack() {
        list = new DLinkedList<>();
    }


    @Override
    public void push(T t) {
        list.goToEnd();
        list.insert(t);
    }


    @Override
    public T pop() {
        if (isEmpty()) {
            return null;
        }
        list.goToEnd();
        return list.remove();
    }

    @Override
    public T top() {
        list.goToEnd();
        return list.getCursor();
    }

    @Override
    public boolean isEmpty() {
        return list.isEmpty();
    }

    @Override
    public String toString() {
        if (isEmpty()) {
            return "[]";
        }
        StringBuilder sb = new StringBuilder();
        list.goToEnd();
        sb.append("[");

        while (true) {
            sb.append(list.getCursor().toString());
            if (!list.hasPrev()) {
                break;
            }
            list.getPrev();
            sb.append(", ");
        }
        sb.append("]");
        return sb.toString();


    }
}
