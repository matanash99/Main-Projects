package il.ac.telhai.ds.trees;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.StreamTokenizer;

public class EvaluatePostfix {

	private static StreamTokenizer tokenizer = new StreamTokenizer(new InputStreamReader(System.in));
	private static Stack<Double> myStack = new DLinkedListStack<>();

	public static void main(String[] args) throws IOException {
		tokenizer.slashSlashComments(false);
		tokenizer.ordinaryChar('/');

		int operatorCount = 0;
		int operandCount = 0;

		while (tokenizer.nextToken() != StreamTokenizer.TT_EOF) {

			String userInput = tokenizer.sval;

			if (tokenizer.ttype == StreamTokenizer.TT_WORD) {
				if (userInput.equals("quit")) {
					break;
				} else {
					System.err.println(tokenizer);
				}
			}

			if (tokenizer.ttype == StreamTokenizer.TT_NUMBER) {
				myStack.push(tokenizer.nval);
				operandCount++;
			} else {

				Double first = myStack.pop();
				Double second = myStack.pop();

				if (tokenizer.ttype != StreamTokenizer.TT_EOL) {
					char operator = (char) tokenizer.ttype;
					operatorCount++;

					if (operatorCount >= operandCount){
						System.err.println(tokenizer);
						System.err.println(myStack);
						System.exit(1);
					}

					switch (operator) {

						case '+':
							myStack.push(second + first);
							break;
						case '*':
							myStack.push(second * first);
							break;

						case '-':
							myStack.push(second - first);
							break;

						case '/':
							myStack.push(second / first);
							break;

						default:
							System.err.println(tokenizer);
							System.err.println(myStack);
							System.exit(1);
					}
				}
			}
		}
		if (myStack.isEmpty() || operandCount - 1 != operatorCount) {
			int diff = operandCount - 1 - operatorCount;
			for (int i = 0; i < diff; i++) {
				myStack.pop();
			}
			System.err.println(tokenizer);
			System.err.println(myStack);
			System.exit(1);
		}

		System.out.println(myStack.top());
	}
}
