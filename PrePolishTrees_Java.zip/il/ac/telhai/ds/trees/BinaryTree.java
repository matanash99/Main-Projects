package il.ac.telhai.ds.trees;

public class BinaryTree <T> implements BinaryTreeI<T> {

    private BinaryTreeI<T> rightSubTree;
    private BinaryTreeI<T> leftSubTree;
    private T value;

    public BinaryTree(T value, BinaryTreeI<T> left, BinaryTreeI<T> right) {
        rightSubTree = right;
        leftSubTree = left;
        this.value = value;
    }

    public BinaryTree(T value) {
        this(value, null, null);
    }

    @Override
    public BinaryTreeI<T> getLeft() {
        return leftSubTree;
    }

    @Override
    public BinaryTreeI<T> getRight() {
        return rightSubTree;
    }

    @Override
    public T getValue() {
        return value;
    }

    @Override
    public void setValue(T value) {
        this.value = value;

    }

    @Override
    public void setLeft(BinaryTreeI<T> left) {
        this.leftSubTree = left;
    }

    @Override
    public void setRight(BinaryTreeI<T> right) {
        this.rightSubTree = right;
    }

    @Override
    public boolean isLeaf() {
        return getRight() == null && getLeft() == null;
    }

    @Override
    public int height() {
        if (isLeaf()) {
            return 0;
        }
        if (rightSubTree == null) {
            return leftSubTree.height() + 1;
        }
        if (leftSubTree == null) {
            return rightSubTree.height() + 1;
        }

        return Math.max(leftSubTree.height(), rightSubTree.height()) + 1;
    }

    @Override
    public int size() {
        if (isLeaf()) {
            return 1;
        }
        if (rightSubTree == null) {
            return leftSubTree.size() + 1;
        }
        if (leftSubTree == null) {
            return rightSubTree.size() + 1;
        }
        return 1 + leftSubTree.size() + rightSubTree.size();
    }

    @Override
    public void clear() {
        setRight(null);
        setLeft(null);
        setValue(null);
    }

    @Override
    public String preOrder(String separationBeforeVal, String separationAfterVal) {
        StringBuilder sb = new StringBuilder();

        sb.append(separationBeforeVal);
        sb.append(value.toString());
        sb.append(separationAfterVal);

        if (getLeft() != null) {
            sb.append(getLeft().preOrder(separationBeforeVal, separationAfterVal));
        }
        if (getRight() != null) {
            sb.append(getRight().preOrder(separationBeforeVal,separationAfterVal));
        }

        return sb.toString();
    }

    @Override
    public String preOrder() {
        return preOrder(" ", " ");
    }

    @Override
    public String inOrder() {
        return inOrder(" ", " ");
    }

    @Override
    public String inOrder(String separationBeforeVal, String separationAfterVal) {
        StringBuilder sb = new StringBuilder();

        if (getLeft() != null) {
            sb.append(getLeft().inOrder(separationBeforeVal, separationAfterVal));
        }
        sb.append(separationBeforeVal);
        sb.append(value.toString());
        sb.append(separationAfterVal);
        if (getRight() != null) {
            sb.append(getRight().inOrder(separationBeforeVal, separationAfterVal));
        }
        return sb.toString();
    }

    @Override
    public String postOrder() {
        return postOrder(" ", " ");
    }

    @Override
    public String postOrder(String separationBeforeVal, String separationAfterVal) {
        StringBuilder sb = new StringBuilder();

        if (getLeft() != null) {
            sb.append(leftSubTree.postOrder(separationBeforeVal,separationAfterVal));
        }
        if (getRight() != null){
            sb.append(rightSubTree.postOrder(separationBeforeVal,separationAfterVal));
        }

        sb.append(separationBeforeVal);
        sb.append(value.toString());
        sb.append(separationAfterVal);
        return sb.toString();
    }
}
