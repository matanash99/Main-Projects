package il.ac.telhai.ds.trees;

public class FullBinaryTree<T> extends BinaryTree<T> {


    public FullBinaryTree(T value, BinaryTree<T> left, BinaryTree<T> right) {
        super(value, right, left);
        if ((right == null && left != null) || (right != null && left == null)) {
            throw new IllegalArgumentException("Should not work");
        }
    }

    public FullBinaryTree(T value) {
        super(value);
    }

    @Override
    public void setLeft(BinaryTreeI<T> left) {


        if (left == null && getLeft() == null) {
            return;
        }

        if (left != null && getLeft().size() != left.size()) {
            throw new IllegalArgumentException("Left child must same size as FullBinaryTree.");
        }

        if (!(left instanceof FullBinaryTree)) {
            throw new IllegalArgumentException("Left child must be an instance of FullBinaryTree.");
        }
        if (getRight() == null) {
            throw new IllegalArgumentException("Cannot set left child without setting right child.");
        }
        super.setLeft(left);
    }

    @Override
    public void setRight(BinaryTreeI<T> right) {
        if (right == null && getRight() == null) {
            return;
        }

        if (right != null && getRight().size() != right.size()) {
            throw new IllegalArgumentException("Left child must same size as FullBinaryTree.");
        }

        if (!(right instanceof FullBinaryTree)) {
            throw new IllegalArgumentException("Right child must be an instance of FullBinaryTree.");
        }

        if (getLeft() == null) {
            throw new IllegalArgumentException("Cannot set right child without setting left child.");
        }

        super.setRight(right);
    }






    @Override
    public String inOrder(String separationBeforeVal, String separationAfterVal) {
        StringBuilder sb = new StringBuilder();

        if (getLeft() != null) {
            sb.append(separationBeforeVal);
            sb.append(getLeft().inOrder(separationBeforeVal, separationAfterVal));
            sb.append(" ");
        }

        sb.append(getValue().toString());

        if (getRight() != null) {
            sb.append(" ");
            sb.append(getRight().inOrder(separationBeforeVal, separationAfterVal));
            sb.append(separationAfterVal);
        }
        return sb.toString();
    }





}
