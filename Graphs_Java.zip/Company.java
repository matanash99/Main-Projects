public class Company implements Comparable<Company> {
    private String code; // Unique identifier for the company
    private String name;
    private String location;



    public Company(String code, String name, String location) {
        this.code = code;
        this.name = name;
        this.location = location;
    }

    // Getter methods
    public String getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    public String getLocation() {
        return location;
    }

    @Override
    public boolean equals(Object obj){
        Company company = (Company) obj;
        String companyCode = company.getCode();
        if (this.code.equals(companyCode)){
            return true;
        }
        return false;
    }

    @Override
    public int hashCode(){
        return code.hashCode();
    }

    @Override
    public String toString() {
        // Provides a string representation of the course, including all its attributes
        return "Company [" + code + " " + name + " " + location + "]";
    }

    @Override
    public int compareTo(Company o) {

        return this.code.compareTo(o.getCode());
    }






}