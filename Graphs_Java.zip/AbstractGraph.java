import java.util.*;

public class AbstractGraph<V extends Comparable<V>> implements IGraph<V> {


    //Fields
    protected SortedMap<V, List<V>> vertices;

    //Builders
    public AbstractGraph() {
        this.vertices = new TreeMap<>();
    }

    @Override
    public void addVertex(V vertex) {
        if (!this.vertices.containsKey(vertex)) {
            this.vertices.put(vertex, new ArrayList<>());
        }
    }

    @Override
    public void addEdge(V u, V v) {
        if (!this.vertices.containsKey(u)) {
            addVertex(u);
        }
        if (!this.vertices.containsKey(v)) {
            addVertex(v);
        }

        if (!this.containsEdge(u,v)){
            this.vertices.get(u).add(v);
        }

    }

    @Override
    public boolean containsVertex(V v) {
        if (this.vertices.containsKey(v)) {
            return true;
        }
        return false;
    }

    @Override
    public boolean containsEdge(V u, V v) {
        if (!(this.containsVertex(u))) {
            return false;
        }  else if (!(this.containsVertex(v))){
            return false;
        }

        return this.vertices.get(u).contains(v);
    }

    @Override
    public List<V> removeVertex(V v) {

        if (!this.containsVertex(v)) {
            return null;
        }

        List<V> removedEdges = this.vertices.remove(v);
        for (List<V> listOfValues : this.vertices.values()) {
            listOfValues.remove(v);
        }
        return removedEdges;
    }

    @Override
    public boolean removeEdge(V u, V v) {
        if (!containsEdge(u, v)) {
            return false;
        }
        this.vertices.get(u).remove(v);
        return true;
    }

    @Override
    public String getGraphType() {
        return "";
    }

    @Override
    public int numOfVertices() {
        return this.vertices.size();
    }

    @Override
    public int numOfEdges() {
        int count = 0;
        for (List <V> valueList : this.vertices.values()){
            count += valueList.size();
        }
        return count;
    }

    @Override
    public String toString() {
        return "";
    }

}