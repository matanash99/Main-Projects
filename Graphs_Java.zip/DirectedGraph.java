import java.util.*;

public class DirectedGraph<V extends Comparable<V>> extends AbstractGraph<V> {

    //Builder
    public DirectedGraph() {
        super();
    }

    @Override
    public String getGraphType() {
        return "Directed Graph";
    }


    @Override
    public String toString() {
        String str = "DirectedGraph:\t";

        int keyCount = 0;

        for (V key : this.vertices.keySet()) {
            str += key + ":";
            List<V> valueList = this.vertices.get(key);

            for (int i = 0; i < valueList.size(); i++) {
                str += valueList.get(i);
                if (i < valueList.size() - 1) {
                    str += "->";
                }
            }
            keyCount++;

            if (keyCount < this.numOfVertices()){
                str += " ";
            }

        }
        return str;
    }
}