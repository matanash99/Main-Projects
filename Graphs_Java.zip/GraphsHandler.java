import java.io.*;
import java.util.*;


public class GraphsHandler {

    public static void main(String[] args) throws IOException {

        Scanner sc1 = new Scanner(new File("ex3_legal.txt"));
        List<IGraph<String>> list = new ArrayList<>();
        SortedMap<String, SortedSet<IGraph<String>>> map = new TreeMap<>();
        SortedSet<IGraph<String>> setDirected = new TreeSet<>(new CompareGraph());
        SortedSet<IGraph<String>> setUndirected = new TreeSet<>(new CompareGraph());
        String directedString = "DirectedGraph";
        String undirectedString = "UndirectedGraph";

        while (sc1.hasNextLine()) {
            String line = sc1.nextLine();
            IGraph<String> graph = GraphUtils.string2Graph(line);
            list.add(graph);
            Scanner sc2 = new Scanner(line);


            sc2.useDelimiter("\t");
            String graphType = sc2.next();
            if (graphType.equals(directedString + ":")) {
                setDirected.add(graph);
            } else if (graphType.equals(undirectedString + ":")) {
                setUndirected.add(graph);
            }
            sc2.close();
        }
        map.put(directedString, setDirected);
        map.put(undirectedString, setUndirected);
        Collections.reverse(list);
        sc1.close();

        Writer writeList = new FileWriter("GraphsOutList.txt");
        Writer writeSortMap = new FileWriter("GraphsSortOutMap.txt");
        Writer writeSortList = new FileWriter("GraphsSortOutList.txt");


        for (IGraph<String> graph : list) {
            writeList.write(graph.toString());
            writeList.write("\n");
        }

        Collections.sort(list, new CompareGraph());
        for (IGraph<String> graph : list) {
            writeSortList.write(graph.toString());
            writeSortList.write("\n");
        }

        for (String key : map.keySet()) {
            for (IGraph<String> graph : map.get(key)) {
                writeSortMap.write(graph.toString());
                writeSortMap.write("\n");
            }
        }
        writeSortMap.flush();
        writeSortMap.close();
        writeList.flush();
        writeList.close();
        writeSortList.flush();
        writeSortList.close();
    }
}