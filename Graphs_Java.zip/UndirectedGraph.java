import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SortedMap;

public class UndirectedGraph<V extends Comparable<V>> extends AbstractGraph<V>{


    //Builders
    public UndirectedGraph() {
        super();
    }

    @Override
    public boolean removeEdge(V u, V v) {
        if (!containsEdge(u, v)) {
            return false;
        }
        this.vertices.get(u).remove(v);
        this.vertices.get(v).remove(u);
        return true;
    }


    @Override
    public int numOfEdges() {
        AbstractGraph<V> abstractGraph = new AbstractGraph<>();

        for (V vertexKey : this.vertices.keySet()) {
            List<V> verticesList = this.vertices.get(vertexKey);
            for (V vertexValue : verticesList) {
                if (!abstractGraph.containsEdge(vertexKey,vertexValue)) {
                    abstractGraph.addEdge(vertexValue, vertexKey);
                }
            }
        }

        return abstractGraph.numOfEdges();
    }

    @Override
    public String getGraphType() {
        return "Undirected Graph";
    }




    @Override
    public void addEdge(V u, V v) {
        if (!(this.vertices.containsKey(u))) {
            addVertex(u);
        }
        if (!(this.vertices.containsKey(v))) {
            addVertex(v);
        }

        if (!(this.containsEdge(u, v))){
            this.vertices.get(u).add(v);
        }

        if (!(this.containsEdge(v, u))){
            this.vertices.get(v).add(u);
        }
    }

    @Override
    public String toString() {
        String str = "UndirectedGraph:\t";

        int keyCount = 0;

        for (V key : this.vertices.keySet()) {
            str += key + ":";
            List<V> valueList = this.vertices.get(key);

            for (int i = 0; i < valueList.size(); i++) {
                str += valueList.get(i);
                if (i < valueList.size() - 1) {
                    str += "->";
                }
            }
            keyCount++;
            if (keyCount < this.vertices.size()) {
                str += " ";
            }

        }

        return str;
    }
}
