import java.util.Scanner;

public class GraphUtils {

	private static double PRECISION = 1.0e-2;

	/**
	 * @param d : double
	 * @return String represents d with 2 places after the decimal point.
	 */
	public static String formatDouble(double d) {
		String res = String.format("%.2f", d);
		if (res.equals("-0.00"))
			res = "0.00";
		return res;
	}

	public static boolean areEqual(double d1, double d2) {
		return Math.abs(d1 - d2) < PRECISION;
	}

	public static IGraph<String> string2Graph(String graph) {
		Scanner sc1 = new Scanner(graph);
		sc1.useDelimiter("\t");

		String graphType = sc1.next();
		String string = sc1.next();
		sc1.close();




		IGraph<String> finalGraph;

		if (graphType.equals("DirectedGraph:")){
            finalGraph = new DirectedGraph<>();
		} else if (graphType.equals("UndirectedGraph:")) {
			finalGraph = new UndirectedGraph<>();
		} else {
			throw new IllegalArgumentException("Unknown graph type: " + graphType);
		}

		Scanner sc2 = new Scanner(string);
		sc2.useDelimiter(" ");

		while (sc2.hasNext()) {
			String vertexAndEdges = sc2.next();
			Scanner sc3 = new Scanner(vertexAndEdges);
			sc3.useDelimiter(":");

			String fromVertex = sc3.next();
			finalGraph.addVertex(fromVertex);

			if (sc3.hasNext()) {
				String edges = sc3.next();
				Scanner sc4 = new Scanner(edges);
				sc4.useDelimiter("->");

				while (sc4.hasNext()) {
					String toVertex = sc4.next();
					finalGraph.addVertex(toVertex);
					finalGraph.addEdge(fromVertex, toVertex);
				}
				sc4.close();
			}
			sc3.close();
		}
		sc2.close();

		return finalGraph;
	}

}