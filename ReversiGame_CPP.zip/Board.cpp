#include "Board.h"

Board::Board() {

    for (int i = 0; i < board.getDimension(); i++) {
        for (int j = 0; j < board.getDimension(); j++) {
            board.set(i,j,'O');
        }
    }
    board.set(3,3,'W');
    board.set(4,4,'W');
    board.set(4,3,'B');
    board.set(3,4,'B');
}


void Board::set(int row, char col, char value) {
    int i = row - 1;
    int j = col - 'A';
    board.set(i , j, value);
}

char Board::get(int row, char col) {
    int i = row - 1;
    int j = col - 'A';
    return board.get(i, j);
}

int Board::getDimension() {
    return board.getDimension();
}


void Board::print() {
    board.print();
}





