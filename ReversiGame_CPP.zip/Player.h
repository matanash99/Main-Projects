#ifndef EXERCISE_2_PLAYER_H
#define EXERCISE_2_PLAYER_H

class Player {

private:
    char color;

public:
    Player(char color) : color(color){};
    ~Player(){}
    char getColor(){return color;}
    char getOpponentColor() {
        if (color == 'B'){
            return 'W';
        }
        return 'B';
    }
};

#endif
