#ifndef EXERCISE_2_REVERSI_H
#define EXERCISE_2_REVERSI_H
#include "Board.h"
#include "Player.h"


class Reversi {

private:
    Board boardGame;

public:
    Reversi(){}
    ~Reversi(){}
    bool makeMove(const string& playerInput, Player player);
    void flip(int row, char col, Player player);
    void printBoard();
    bool isGameOver();
    bool checkDirection(int row, char col, int diffRow, int diffCol, Player player);
    bool validRowCol(int row, char col);
    bool isValidMove(const int& row,const char& col, Player const& player);
    void printCeremony();
    void quit(Player currentPlayer);
};




#endif //EXERCISE_2_REVERSI_H
