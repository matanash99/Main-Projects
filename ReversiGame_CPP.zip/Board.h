#ifndef EXERCISE_2_BOARD_H
#define EXERCISE_2_BOARD_H
#include "Matrix.h"

class Board {
    
private:

    Matrix board;

public:

    Board();
    ~Board(){}
    void set(int row, char col, char value);
    int getDimension();
    char get(int row, char col);
    void print();

};

#endif //EXERCISE_2_BOARD_H
