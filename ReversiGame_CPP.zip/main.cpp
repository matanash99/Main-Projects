#include <iostream>
#include "Reversi.h"

using namespace std;

#include "Reversi.h"

int main() {



    Reversi game;
    Player player1('B');
    Player player2('W');

    Player currentPlayer = player1;

    game.printBoard();
    bool movePassed = false;
    while (!game.isGameOver()) {


        bool moveSuccessful = false;

        while (!moveSuccessful) {

            string move;
            cout << currentPlayer.getColor() << ":\n";
            cin >> move;

            if (move == "QUIT") {
                game.quit(currentPlayer);
                return 0;
            }
            if (move == "PASS") {
                cout << currentPlayer.getColor() <<  ": PASS\n";
                if (movePassed) {
                    cout << "The game ends in a tie.\n";
                    return 0;
                }
                moveSuccessful = true;
                movePassed = true;
                game.printBoard();
                continue;
            }


            // Check user input
            if (move.length() != 2 || move[0] < 'A' || move[0] > 'F' || move[1] < '1' || move[1] > '8') {
                cerr << "Invalid move; the game awaits a valid move.\n";
                continue;
            }

            // Attempt the move
            moveSuccessful = game.makeMove(move, currentPlayer);
            movePassed = false;



            if (!moveSuccessful) {
                cerr << "Invalid move; the game awaits a valid move.\n";
            } else {
                game.printBoard();
            }
        }
        if (currentPlayer.getColor() == player1.getColor()) {
            currentPlayer = player2;
        }
        else {
            currentPlayer = player1;
        }

    }
    game.printCeremony();


    return 0;
}