#ifndef EXERCISE_2_MATRIX_H
#define EXERCISE_2_MATRIX_H
#include <iostream>

using namespace std;

class Matrix {

private:
    char** matrix;
    int dimension;

public:
    Matrix();// ctor
    ~Matrix(); //Destroyer
    void set(int i, int j, char ch);
    char get(int i, int j);
    int getDimension();
    void print();
};

#endif //EXERCISE_2_MATRIX_H
