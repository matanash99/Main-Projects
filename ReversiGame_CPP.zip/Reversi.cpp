#include "Reversi.h"

bool Reversi::makeMove(const string &playerInput, Player player) {

    char col = playerInput[0];
    int row = playerInput[1] - '0';

    if (boardGame.get(row, col) != 'O') {
        return false;
    }

    if (isValidMove(row, col, player)) {
        flip(row, col, player);
        boardGame.set(row, col, player.getColor());
        return true;
    }
    return false;
}

void Reversi::quit(Player currentPlayer) {
    cout << currentPlayer.getColor() << ": QUIT\n" << currentPlayer.getOpponentColor() << " wins the game.\n";
}

bool Reversi::validRowCol(int row, char col) {
    return row >= 1 && row <= 8 && col >= 'A' && col <= 'F';
}

void Reversi::printBoard(){
    boardGame.print();
}

void Reversi::flip(int row, char col, Player player) {
    char opponentColor = player.getOpponentColor();

    // Check all 8 directions
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (i == 0 && j == 0) continue;  // Skip 0 movement

            if (checkDirection(row, col, i, j, player)) {
                int newRow = row + i;
                char newCol = col + j;

                while (boardGame.get(newRow, newCol) == opponentColor) {
                    boardGame.set(newRow, newCol, player.getColor());
                    newRow += i;
                    newCol += j;
                }
            }
        }
    }
}

bool Reversi::checkDirection(int row, char col, int diffRow, int diffCol, Player player){

    char opponentColor = player.getOpponentColor();
    bool hasOpponent = false;

    row += diffRow;
    col += diffCol;

    while(validRowCol(row, col)) {
        if (boardGame.get(row,col) == opponentColor) {
            hasOpponent = true;
        } else if (boardGame.get(row, col) == player.getColor()) {
            return hasOpponent;
        } else {
            break;
        }
        row += diffRow;
        col += diffCol;
    }
    return false;
}

bool Reversi::isValidMove(const int& row,const char& col, Player const& player){

    // Check all directions
    for (int i = -1; i <= 1; i++) {
        for (int j = -1; j <= 1; j++) {
            if (checkDirection(row,col,i,j,player)) {
                return true;
            }
        }
    }
    return false;
}

bool Reversi::isGameOver() {
    for (int row = 1; row <= 8; ++row) {
        for (char col = 'A'; col <= 'H'; ++col) {
            if (boardGame.get(row, col) == 'O' && (isValidMove(row, col, Player('B')) || isValidMove(row, col, Player('W')))) {
                return false;
            }
        }
    }
    return true;
}

void Reversi::printCeremony() {
    int wCount = 0, bCount = 0;

    for (int i = 0; i < boardGame.getDimension(); i++) {
        for (char j = 'A'; j < 'H'; j++) {
            if (boardGame.get(i,j) == 'W'){
                wCount++;
            }
            else if (boardGame.get(i,j) == 'B') {
                bCount++;
            }
        }
    }
    if (bCount == wCount) {
        cout << "The game ends in a tie.\n";
        return;
    }
    if (bCount > wCount) {
        cout << "B wins the game.\n";
        return;
    }
    cout << "W wins the game.\n";
}