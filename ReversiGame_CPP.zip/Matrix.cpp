#include "Matrix.h"

Matrix::Matrix() {
    dimension = 8;
    matrix = new char*[dimension];
    for (int i = 0; i < dimension; i++) {
        matrix[i] = new char[dimension];
    }
}

Matrix::~Matrix(){
    for (int i = 0; i < this->dimension; i++) {
        delete[] matrix[i];
    }
    delete[] matrix;
}

void Matrix::set(int i, int j, char ch){
    matrix[i][j] = ch;
}

char Matrix::get(int i, int j) {
    return matrix[i][j];
}

void Matrix::print() {

    int i, j;
    for (i = 0; i < 8; i++) {
        for (j = 0; j < 8; j++) {
            if (j < 7){
                cout << matrix[i][j] << " ";
            }
            else {
                cout << matrix[i][j];
            }
        }
        cout << endl;
    }
}

int Matrix::getDimension() {
    return dimension;
}